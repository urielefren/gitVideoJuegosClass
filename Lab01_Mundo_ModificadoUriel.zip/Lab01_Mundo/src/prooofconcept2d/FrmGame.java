/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package prooofconcept2d;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author servkey
 */
public class FrmGame extends JFrame implements KeyListener{
    private Thread t;
    private CanvasDib c;
    public FrmGame(CanvasDib c){
       
        this.c = c;
        add(c);
        addKeyListener(this);
        //Iniciar hilo
        t = new Thread(){
              public void run(){
                  updating();
              }
        };
        t.start();
     
        this.getContentPane().setBackground(Color.WHITE);
    }
    
    public void updating(){
        while (true){
            try {
                Thread.sleep(100);
                c.repaint();
            } catch (InterruptedException ex) {
                Logger.getLogger(FrmGame.class.getName()).log(Level.SEVERE, null, ex);
            }           
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("pressed:"+e.getKeyCode());
        int keypressed = e.getKeyCode();
        if(keypressed==37){//izquierda
            if(c.getX()>0){
                c.setX(c.getX()-2);
            }else{
                c.setX(0);
            }
        }
        else if(keypressed==38){//arriba
            if(c.getY()>0){
                c.setY(c.getY()-2);
            }else{
                c.setY(0);
            }
        }
        else if(keypressed==39){//derecha
            if(c.getX()<this.getSize().width){
                c.setX(c.getX()+2);
            }else{
                c.setX(this.getSize().width);
            }
        }
        else if(keypressed==40){//abajo
            if(c.getY()<this.getSize().height){
                c.setY(c.getY()+2);
            }else{
                c.setY(this.getSize().height);
            }
        }
        c.repaint();
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
